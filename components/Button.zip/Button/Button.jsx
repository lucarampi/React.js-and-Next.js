import styles from './Button.css';

export default function Button(props) {
    return (
        <div className="container">
            <div className="mainDiv">
                <div className="myDiv"></div>
                <button className="myButton"> Login </button>
            </div>
        </div>
    );
}